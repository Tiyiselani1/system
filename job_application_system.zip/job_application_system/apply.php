<?php
include 'config.php';

// Fetch job details if job ID is provided
if (isset($_GET['job_id'])) {
    $job_id = $_GET['job_id'];
    $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = :id");
    $stmt->execute([':id' => $job_id]);
    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$job) {
        die("Job not found.");
    }
} else {
    die("Invalid job ID.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $resume = $_FILES['resume'];

    // Validate and upload resume
    if ($resume['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $resumePath = $uploadDir . basename($resume['name']);
        move_uploaded_file($resume['tmp_name'], $resumePath);

        // Save application to database
        $stmt = $conn->prepare("INSERT INTO applications (job_id, name, email, phone, resume_path) VALUES (:job_id, :name, :email, :phone, :resume_path)");
        $stmt->execute([
            ':job_id' => $job_id,
            ':name' => $name,
            ':email' => $email,
            ':phone' => $phone,
            ':resume_path' => $resumePath
        ]);

        echo "<p>Application submitted successfully!</p>";
    } else {
        echo "<p>Error uploading resume.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for <?php echo htmlspecialchars($job['title']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Apply for <?php echo htmlspecialchars($job['title']); ?></h1>
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <input type="file" name="resume" accept=".pdf,.doc,.docx" required>
        <button type="submit">Submit Application</button>
    </form>
</body>
</html>