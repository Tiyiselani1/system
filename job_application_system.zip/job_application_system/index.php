<?php
include 'config.php';

// Fetch all jobs
$stmt = $conn->query("SELECT * FROM jobs ORDER BY created_at DESC");
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
  <title>job application</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/logo3.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800|Montserrat:300,400,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/magnific-popup/magnific-popup.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="css/styles.css">
      <link rel="stylesheet" type="text/css" href="css/button.css">
      <link rel="stylesheet" type="text/css" href="css/hover.css">
  
    <style>
        
      
        .filters {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .filters select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .job-listings {
    display: flex;
    flex-wrap: wrap;
    flex-direction: row; /* Ensure items are placed from left to right */
    justify-content: flex-start; /* Align items to the start of the container */
    gap: 20px;
    padding: 20px;
}
        .job-card {
            background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
    width: 300px;
    transition: transform 0.3s, box-shadow 0.3s;
        }
        .job-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .job-card h2 {
            margin: 0;
            color: #333;
            font-size: 1.5em;
        }
        .job-card p {
            margin: 10px 0;
            color: #666;
        }
        .job-card .details {
            margin-top: 15px;
        }
        .job-card .details span {
            display: inline-block;
            background-color: #e0e0e0;
            padding: 5px 10px;
            border-radius: 15px;
            margin-right: 5px;
            font-size: 0.9em;
            color: #555;
        }
        .job-card .details span.type {
            background-color: #4CAF50;
            color: #fff;
        }
        .job-card .details span.employment {
            background-color: #2196F3;
            color: #fff;
        }
        .job-card .apply-button {
            display: inline-block;
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 15px;
        }
        .job-card .apply-button:hover {
            background-color: #45a049;
        }
        .job-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

    </style>
</head>
<body id="body">
   <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        
       
        <a href="#body"><img src="img/logo2.png" class="logo-desktop" /></a>
        <img src="placeholder" alt="Mobile Logo" class="logo-mobile">
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#body">Home</a></li>
          <li><a href="index2.html#about">About Us</a></li>
          <li><a href="index2.html#services">Nav</a></li>
          <li><a href="index2.html#team">Nav</a></li>
          <li><a href="index2.html#contact">Nav</a></li>
         <li><a href="corporate.html">Nav</a></li>
          <li><a href="index.php">Nav</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->
<section id="about">
    <div class="filters">
        <label for="job-type">Filter by Job Type:</label>
        <select id="job-type">
            <option value="all">All Positions</option>
            <option value="Project Management">Job Name</option>
            <option value="HR">Job Name</option>
            <option value="Software Development">Job Name</option>
            <option value="Marketing">Job Name</option>
        </select>
    </div>

    <div class="job-listings">
        <?php if (count($jobs) > 0): ?>
            <?php foreach ($jobs as $job): ?>
                <div class="job-card" data-type="<?php echo htmlspecialchars($job['type']); ?>">
                    <h2><?php echo htmlspecialchars($job['title']); ?></h2>
                    <p><?php echo htmlspecialchars($job['location']); ?></p>
                    <p><?php echo htmlspecialchars($job['description']); ?></p>
                    <div class="details">
                        <span class="type"><?php echo htmlspecialchars($job['type']); ?></span>
                        <span class="employment"><?php echo htmlspecialchars($job['employment_type']); ?></span>
                    </div>
                    <a href="apply.php?job_id=<?php echo $job['id']; ?>" class="apply-button">Apply Now</a>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No jobs available at the moment.</p>
        <?php endif; ?>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br>
</section>
<footer id="footer">
    
    <div class="container">
      
      <div class="copyright">
        &copy; Copyright <strong>Charles</strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        designed by <br><a href="">Charles</a> 
      </div>
    </div>
  </footer><!-- #footer -->
   

    <script>
        // JavaScript for filtering jobs
        document.getElementById('job-type').addEventListener('change', function () {
            const selectedType = this.value;
            const jobCards = document.querySelectorAll('.job-card');

            jobCards.forEach(card => {
                const cardType = card.getAttribute('data-type');
                if (selectedType === 'all' || cardType === selectedType) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    </script>
    <script>
    document.querySelectorAll('.accordion-header').forEach(header => {
      header.addEventListener('click', () => {
        const item = header.parentElement;
        const wasActive = item.classList.contains('active');
        
        document.querySelectorAll('.accordion-item').forEach(item => {
          item.classList.remove('active');
        });
        
        if (!wasActive) {
          item.classList.add('active');
        }
      });
    });
  </script>
    <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/magnific-popup/magnific-popup.min.js"></script>
  <script src="lib/sticky/sticky.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD8HeI8o-c1NppZA-92oYlXakhDPYR7XMY"></script>
  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
</body>
</html>