<?php
include 'config.php';

// Handle Add Job
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_job'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $type = $_POST['type'];
    $employment_type = $_POST['employment_type'];

    $stmt = $conn->prepare("INSERT INTO jobs (title, description, location, type, employment_type) VALUES (:title, :description, :location, :type, :employment_type)");
    $stmt->execute([
        ':title' => $title,
        ':description' => $description,
        ':location' => $location,
        ':type' => $type,
        ':employment_type' => $employment_type
    ]);

    header("Location: admin.php");
    exit();
}

// Handle Edit Job
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_job'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $type = $_POST['type'];
    $employment_type = $_POST['employment_type'];

    $stmt = $conn->prepare("UPDATE jobs SET title = :title, description = :description, location = :location, type = :type, employment_type = :employment_type WHERE id = :id");
    $stmt->execute([
        ':id' => $id,
        ':title' => $title,
        ':description' => $description,
        ':location' => $location,
        ':type' => $type,
        ':employment_type' => $employment_type
    ]);

    header("Location: admin.php");
    exit();
}

// Handle Delete Job
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];

    // Delete related applications first
    $stmt = $conn->prepare("DELETE FROM applications WHERE job_id = :job_id");
    $stmt->execute([':job_id' => $id]);

    // Now delete the job
    $stmt = $conn->prepare("DELETE FROM jobs WHERE id = :id");
    $stmt->execute([':id' => $id]);

    header("Location: admin.php");
    exit();
}

// Fetch all jobs
$stmt = $conn->query("SELECT * FROM jobs ORDER BY created_at DESC");
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 20px auto;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .job-list {
            margin-top: 20px;
        }
        .job-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .job-card h2 {
            margin: 0;
            color: #333;
        }
        .job-card p {
            margin: 10px 0;
            color: #666;
        }
        .job-card .actions {
            margin-top: 10px;
        }
        .job-card .actions a {
            text-decoration: none;
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
        }
        .job-card .actions a.edit {
            background-color: #2196F3;
        }
        .job-card .actions a.delete {
            background-color: #f44336;
        }
    </style>
</head>
<body>
    <h1>Admin Panel</h1>

    <!-- Add Job Form -->
    <form method="POST" action="">
        <h2>Add New Job</h2>
        <input type="text" name="title" placeholder="Job Title" required>
        <textarea name="description" placeholder="Job Description" rows="5" required></textarea>
        <input type="text" name="location" placeholder="Location" required>
        <select name="type" required>
            <option value="">Select Job Type</option>
            <option value="Project Management">Project Management</option>
            <option value="HR">HR</option>
            <option value="Software Development">Software Development</option>
            <option value="Marketing">Marketing</option>
        </select>
        <select name="employment_type" required>
            <option value="">Select Employment Type</option>
            <option value="Full-time">Full-time</option>
            <option value="Part-time">Part-time</option>
            <option value="Remote">Remote</option>
        </select>
        <button type="submit" name="add_job">Add Job</button>
    </form>

    <!-- Job List -->
    <div class="job-list">
        <h2>Job Listings</h2>
        <?php if (count($jobs) > 0): ?>
            <?php foreach ($jobs as $job): ?>
                <div class="job-card">
                    <h2><?php echo htmlspecialchars($job['title']); ?></h2>
                    <p><?php echo htmlspecialchars($job['description']); ?></p>
                    <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
                    <p><strong>Type:</strong> <?php echo htmlspecialchars($job['type']); ?></p>
                    <p><strong>Employment Type:</strong> <?php echo htmlspecialchars($job['employment_type']); ?></p>
                    <div class="actions">
                        <a href="admin.php?edit_id=<?php echo $job['id']; ?>" class="edit">Edit</a>
                        <a href="admin.php?delete_id=<?php echo $job['id']; ?>" class="delete" onclick="return confirm('Are you sure you want to delete this job?');">Delete</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No jobs available.</p>
        <?php endif; ?>
    </div>

    <!-- Edit Job Form (Hidden by Default) -->
    <?php if (isset($_GET['edit_id'])): ?>
        <?php
        $edit_id = $_GET['edit_id'];
        $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = :id");
        $stmt->execute([':id' => $edit_id]);
        $job = $stmt->fetch(PDO::FETCH_ASSOC);
        ?>
        <form method="POST" action="">
            <h2>Edit Job</h2>
            <input type="hidden" name="id" value="<?php echo $job['id']; ?>">
            <input type="text" name="title" placeholder="Job Title" value="<?php echo htmlspecialchars($job['title']); ?>" required>
            <textarea name="description" placeholder="Job Description" rows="5" required><?php echo htmlspecialchars($job['description']); ?></textarea>
            <input type="text" name="location" placeholder="Location" value="<?php echo htmlspecialchars($job['location']); ?>" required>
            <select name="type" required>
                <option value="Project Management" <?php echo $job['type'] === 'Project Management' ? 'selected' : ''; ?>>Project Management</option>
                <option value="HR" <?php echo $job['type'] === 'HR' ? 'selected' : ''; ?>>HR</option>
                <option value="Software Development" <?php echo $job['type'] === 'Software Development' ? 'selected' : ''; ?>>Software Development</option>
                <option value="Marketing" <?php echo $job['type'] === 'Marketing' ? 'selected' : ''; ?>>Marketing</option>
            </select>
            <select name="employment_type" required>
                <option value="Full-time" <?php echo $job['employment_type'] === 'Full-time' ? 'selected' : ''; ?>>Full-time</option>
                <option value="Part-time" <?php echo $job['employment_type'] === 'Part-time' ? 'selected' : ''; ?>>Part-time</option>
                <option value="Remote" <?php echo $job['employment_type'] === 'Remote' ? 'selected' : ''; ?>>Remote</option>
            </select>
            <button type="submit" name="edit_job">Update Job</button>
        </form>
    <?php endif; ?>
</body>
</html>